package example;

public class show {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		oopsexample o = new oopsexample();
		o.student();
		o.totalmarks();
		o.avgmarks();
		o.passedmarks();
		
		oopsexample o2 = new oopsexample();
		o2.student();
		o2.totalmarks();
		o2.avgmarks();
		o2.passedmarks();
		
		o.display();
		o2.display();
		
				
	}

}
