package example;

import java.util.Scanner;

public class Employee {

	int ecode;
	String ename;
	double bsal,msal,Hra,da, ta,ysal,it,pf,netsal;
	
	
	void input()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter ecode number : ");
		ecode = sc.nextInt();
		System.out.println("enter emp name : ");
		ename = sc.next();
		System.out.println("enter Basic sal : ");
		bsal = sc.nextInt();
		
	}
	void calc()
	{
		msal=(bsal+ bsal*.40 + bsal*.20 + bsal*.10); //basic + hra+da+ta
	    ysal = msal*12;
	    netsal= (ysal -ysal*.20 - ysal*.10); //yearlysalry +it+pf
	   
	}
	
	void display()
	{
		System.out.println("Employee id : "+ecode);
		System.out.println("Employee name : "+ename);
		System.out.println("Monthly salary : "+msal);
		System.out.println("Yearly salary : "+ysal);
		System.out.println("Net salary : "+netsal);
	}
	
	
	
	
	
	
}
