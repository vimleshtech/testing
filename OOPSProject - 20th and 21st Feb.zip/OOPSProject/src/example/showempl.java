package example;



public class showempl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		Employee empl = new Employee();
		empl.input();
		empl.calc();
		empl.display();
		

		Employee emp2 = new Employee();
		emp2.input();
		emp2.calc();
		emp2.display();
		
		Employee emp3 = new Employee();
		emp3.input();
		emp3.calc();
		emp3.display();
		 */
		Employee[] empl = new Employee[4];
		
		for(int i=0;i<4;i++)
		{
			empl[i] = new Employee();
			empl[i].input();
			empl[i].calc();
			
			
		}
		
		for(int i=0; i<4;i++)
			empl[i].display();
		
		
	}

}
