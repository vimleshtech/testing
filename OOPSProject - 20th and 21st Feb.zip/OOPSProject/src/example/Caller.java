package example;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e =new Employee();
		//e.newemp();
		//e.computesalary();
		//e.show();
	}

}
