package example;

import java.util.Scanner;

public class oopsexample {

		int rollno;
		String name;
		int marks1 , marks2,marks3,marks4 ,marks5;
		double total,avgmarks,passedmarks;
		String msg="";
		
		void student()
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("enter roll number : ");
			rollno = sc.nextInt();
			System.out.println("enter student name : ");
			name = sc.next();
			System.out.println("enter marks of first subject : ");
			marks1 = sc.nextInt();
			System.out.println("enter marks of 2nd subject : ");
			marks2 = sc.nextInt();
			System.out.println("enter marks of 3rd subject : ");
			marks3 = sc.nextInt();
			System.out.println("enter marks of  4th subject : ");
			marks4 = sc.nextInt();
			System.out.println("enter marks of 5th subject : ");
			marks5 = sc.nextInt();
		}
		
		void totalmarks()
		
		{
			total = (marks1 + marks2 + marks3 + marks4 + marks5); 
		}
		
		void avgmarks()
		{
			avgmarks = (total /5);
		}
		
		void passedmarks() {
			
			passedmarks = (total/5);
			if(passedmarks>40)
			{
				//System.out.println("Student is passed");
				msg ="pass";
			}
			else {
				//System.out.println("student is failed");
				msg ="fail";
			}
		}
		
		void display()
		{
			System.out.println("student rollnumber : "+rollno);
			System.out.println("student name : "+name);
			System.out.println("student marks1 : "+marks1);
			System.out.println("student marks2 : "+marks2);
			System.out.println("student marks3 : "+marks3);
			System.out.println("student marks4 : "+marks4);
			System.out.println("student marks5 : "+marks5);
			System.out.println("student total marks : "+total);
			System.out.println("student average marks : "+avgmarks);
			System.out.println("Final Result : "+msg);
		
		}
		
	}


