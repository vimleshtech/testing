package example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter data : ");
		String name = sc.nextLine();
		
		String ns = name.toUpperCase();
		System.out.println("You have entered : "+ns);
		
		ns = name.toLowerCase();
		System.out.println("You have entered : "+ns);
		
		
		ns = name.replace("a", "xy");
		System.out.println("You have entered : "+ns);
		
		int l = name.length();
		System.out.println("count "+l);
		
		
		ns = name.trim();
		System.out.println(ns);
		
		ns = name.substring(2, 5); //raman 2 to <5
		System.out.println(ns);
		
		
		char c = name.charAt(3);
		System.out.println(c);
		//convert to ascii
		int a = c; 
		System.out.println(a);
		
		
		int ps = name.indexOf("m");
		System.out.println(ps);
		
		
		String data[] = name.split(" "); //{"raman","sinha"}		
		System.out.println(data[0]); //print first name
		
		//conditional
		if(name.contains("ma"))
		{
			System.out.println("ma is matched");
		}
		else
		{
			System.out.println("ma is not matched");
		}
		//
		if(name.equals("raman sinha"))
		{
			System.out.println("is equal");
		}
		else
		{
			System.out.println("is not equal");
		}
		
		//
		
		if(name.equalsIgnoreCase("RAMAN SINHA"))
		{
			System.out.println("is equal");
		}
		else
		{
			System.out.println("is not equal");
		}
		//
		if(name.startsWith("ra"))
		{
			System.out.println("start with ra");
		}
		else
		{
			System.out.println("not start with ra");
		}
		//
		if(name.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
	}

}
