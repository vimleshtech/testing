package example;

public class ArrayExample {

	public static void main(String[] args) {
		// Single dimenssion array
		
		int a[] = new int[2];
		a[0]=1;
		a[1]=11;
		
		//read /access one element
		System.out.println(a[1]);
		
		//using loop
		for(int i=0;i<2;i++)
		{
			System.out.println(a[i]);
		}
		
		//or 
		String d[] = {"raman","jatin","divya"};
		
		for(int i=0;i<3;i++)
		{
			System.out.println(d[i]);
		}
		
		
		
		//Two Dimenssion array
		int nn[][] =new int[3][2];
		
		nn[0][0] =1;
		nn[0][1] =2;
		
		nn[1][0] =3;		
		nn[1][1] =4;
		
		nn[2][0] =5;
		nn[2][1] =6;
		
		System.out.println(nn[1][1]);//access one element;
		//access all
		for(int i=0; i<3;i++) //row
		{
			for(int c=0; c<2;c++) //col
			{
				System.out.print(nn[i][c]+"\t");//no change line
			}
			System.out.println(); //change line
		}
		
	}

}
