package example;

import java.util.Scanner;

public class DynamicArray {

	public static void main(String[] args) {

		
		String data[] =new String[4];
		Scanner sc =new Scanner(System.in);
		
		for(int i=0;i<4;i++)
		{
			System.out.println("enter name : ");
			data[i] = sc.nextLine();
		}

		for(String n:data)//foreach , read all element one by one 
		{
			System.out.println(n);
		}
	}

}
