package com.mysql;

public enum jdbc {

}
