//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package utilities;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class Common {
	public static String uname;
	public static String password;

	public static String test_user;
	public static String test_password;

	public static int sliderImage = 0;
	private static Map<String, String> innerResultMap = null;

	/* To read text content */

	public static String readContent(String fileName) {
		BufferedReader reader;
		StringBuilder text = new StringBuilder();
		try {
			reader = new BufferedReader(new FileReader(fileName));

			String line = null;
			while ((line = reader.readLine()) != null) {
				// System.out.println(line);
				text.append(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return text.toString();
	}

	public void setUserInput() {
		try {
			InputStream input = new BufferedInputStream(new FileInputStream(
					"D:/Adda52-Automation/Adda52/User.xls"));

			POIFSFileSystem fs = new POIFSFileSystem(input);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);

			Iterator rows = sheet.rowIterator();

			int rowindex = 0;
			int colindex = 0;
			while (rows.hasNext()) {
				if (rowindex > 1)
					break;

				HSSFRow row = (HSSFRow) rows.next();
				System.out.println("\n");
				Iterator cells = row.cellIterator();

				while (cells.hasNext()) {
					HSSFCell cell = (HSSFCell) cells.next();

					if (HSSFCell.CELL_TYPE_NUMERIC == cell.getCellType()) {
						System.out.print(cell.getNumericCellValue() + " ");
					} else if (HSSFCell.CELL_TYPE_STRING == cell.getCellType()) {
						if (colindex == 0)
							uname = cell.getStringCellValue();
						else
							password = cell.getStringCellValue();
						System.out.print(cell.getStringCellValue() + " ");
					} else if (HSSFCell.CELL_TYPE_BOOLEAN == cell.getCellType()) {
						System.out.print(cell.getBooleanCellValue() + " ");
					} else if (HSSFCell.CELL_TYPE_BLANK == cell.getCellType()) {
						System.out.print("BLANK ");
					} else {
						System.out.print("Unknown cell type");
					}

					colindex++;
				}

				rowindex++;

			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public void setTestInput() {
		try {

			test_user = ConfigUtility.getProperty("user_name");
			test_password = ConfigUtility.getProperty("password");

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	/*
	 * public void sendEmail( String aFromEmailAddr, String aToEmailAddr, String
	 * aSubject, String aBody ){ //Here, no Authenticator argument is used (it
	 * is null). //Authenticators are used to prompt the user for user //name
	 * and password. Session session =
	 * Session.getDefaultInstance(fMailServerConfig, null); MimeMessage message
	 * = new MimeMessage(session); try { //the "from" address may be set in
	 * code, or set in the //config file under "mail.from" ; here, the latter
	 * style is used //message.setFrom(new InternetAddress(aFromEmailAddr));
	 * message.addRecipient( Message.RecipientType.TO, new
	 * InternetAddress(aToEmailAddr) ); message.setSubject(aSubject);
	 * message.setText(aBody); Transport.send(message); } catch
	 * (MessagingException ex){ System.err.println("Cannot send email. " + ex);
	 * } }
	 * 
	 * /** Allows the config to be refreshed at runtime, instead of requiring a
	 * restart.
	 */
	/*
	 * public static void refreshConfig() { fMailServerConfig.clear();
	 * fetchConfig(); }
	 * 
	 * // PRIVATE
	 * 
	 * private static Properties fMailServerConfig = new Properties();
	 * 
	 * static { fetchConfig(); }
	 * 
	 * 
	 * // Open a specific text file containing mail server // parameters, and
	 * populate a corresponding Properties object.
	 * 
	 * private static void fetchConfig() { //This file contains the javax.mail
	 * config properties mentioned above. Path path =
	 * Paths.get("C:\\Temp\\MyMailServer.txt"); try (InputStream input =
	 * Files.newInputStream(path)) { fMailServerConfig.load(input); } catch
	 * (IOException ex){
	 * System.err.println("Cannot open and load mail server properties file.");
	 * } }
	 * 
	 * 
	 * public void saveScreee() throws Exception { WebDriver driver = new
	 * RemoteWebDriver( new URL("http://localhost:4444/wd/hub"),
	 * DesiredCapabilities.firefox());
	 * 
	 * driver.get("http://www.google.com");
	 * 
	 * // RemoteWebDriver does not implement the TakesScreenshot class // if the
	 * driver does have the Capabilities to take a screenshot // then Augmenter
	 * will add the TakesScreenshot methods to the instance WebDriver
	 * augmentedDriver = new Augmenter().augment(driver); File screenshot =
	 * ((TakesScreenshot)augmentedDriver). getScreenshotAs(OutputType.FILE); }
	 */
	// public void saveReportInExce() throws InvalidFormatException, IOException
	// {
	// InputStream inp = new
	// FileInputStream("D:\\Automation\\Adda52\\workbook.xls");
	// //InputStream inp = new FileInputStream("workbook.xlsx");
	//
	// Workbook wb = (Workbook) WorkbookFactory.create(inp);
	// Sheet sheet = wb.getSheet(0);
	// Cell[] row = sheet.getRow(2);
	// System.out.println(row.length);
	//
	// /*Cell cell = row.getCell(3);
	//
	// if (cell == null)
	// cell = row.createCell(3);
	// cell.setCellType(Cell.CELL_TYPE_STRING);
	// cell.setCellValue("a test");
	//
	// // Write the output to a file
	// FileOutputStream fileOut = new FileOutputStream("workbook.xls");
	// wb.write(fileOut);
	// fileOut.close();
	// */
	// }
	public void dbConnectivity() throws ClassNotFoundException, SQLException {
		// Accessing Driver From Jar File
		Class.forName("com.mysql.jdbc.Driver");

		// DB Connection
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/test", "root", "");

		// MySQL Query
		PreparedStatement statement = con
				.prepareStatement("SELECT * FROM tablename WHERE id='1'");

		// Creating Variable to execute query
		ResultSet result = statement.executeQuery();

		while (result.next()) {

			System.out.println(result.getString(2));

		}
	}

	public Map<String, String> getInnerResultMap() {
		if (innerResultMap == null) {
			innerResultMap = new HashMap<String, String>();
		}
		return innerResultMap;
	}

}