//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ExcelUtility {

	public static int GlobalSheetIndex = 0;

	HashMap<Integer, String> cellMap = null;

	public static void main(String[] args) throws Exception {
		ExcelUtility excelUtil = new ExcelUtility();
		// for (HashMap<String, Object> userMap : excelUtil.readUserData()) {
		// // Iterator<Entry<String, Object>> itr =
		// // userMap.entrySet().iterator();
		// // while (itr.hasNext()) {
		// // String key = itr.next().getKey();
		// // System.out.println("KEY   " + key);
		//
		// System.out.println("VALUE  " + userMap.get("userName"));
		// System.out.println("VALUE  " + userMap.get("password"));
		// System.out.println("VALUE  " + userMap.get("email"));
		// System.out.println("VALUE  " + userMap.get("birthYear"));
		// System.out.println("VALUE  " + userMap.get("gender"));
		//
		// // System.out.println("VALUE  " + itr.next().getValue());
		// // }
		// }

		excelUtil.readExcelTestCases("My.xls");
		Iterator<Entry<Integer, String>> itr = excelUtil.cellMap.entrySet()
				.iterator();
		while (itr.hasNext()) {
			int key = itr.next().getKey();
			String value = excelUtil.cellMap.get(key);
			// System.out.println("KEY   " + key);
			// System.out.println("Value   " + value);
		}

	}

	// to-do---Need to modify this method to work for all over excel..for read..
	public void readExcelTestCases(String file) {
		FileInputStream fileIn = null;
		HSSFWorkbook wb = null;
		try {
			/*
			 * TO-DO...Need to work on it so that can pick file from any
			 * location
			 */

			int sheetIndex = GlobalSheetIndex;

			System.out.println("INDEX:" + GlobalSheetIndex);

			// fileIn = new FileInputStream("D:/Adda52-Automation/Adda52/" +
			// file);
			fileIn = new FileInputStream(file);

			wb = new HSSFWorkbook(fileIn);
			HSSFSheet sheet = wb.getSheetAt(GlobalSheetIndex);

			HSSFRow row = null;
			Cell cell;
			cellMap = new HashMap<Integer, String>();
			for (int j = 1; j < sheet.getLastRowNum() + 1; j++) {
				row = sheet.getRow(j);

				cell = row.getCell(0);
				if (cell != null) {
					int type = cell.getCellType();
					if (type == HSSFCell.CELL_TYPE_STRING) {
						String cellValue = cell.getRichStringCellValue()
								.toString();
						// if (file.equals("My.xls")) {
						// if (cellValue.startsWith("TC")) {
						// cellMap = new HashMap<Integer, String>();
						// System.out.println(cellValue);
						// System.out.println(cell.getRowIndex());
						cellMap.put(cell.getRowIndex(), cellValue);
						// }

						// }
						// if (file.equals("User.xls")) {
						// cellMap = new HashMap<Integer, String>();
						// if (cellValue.startsWith("TC")) {
						// System.out.println(cellValue);
						// System.out.println(cell.getRowIndex());
						// cellMap.put(cell.getRowIndex(), cellValue);
						// }
						// }
						// if (file.equals("Links.xls")) {
						// cellMap = new HashMap<Integer, String>();
						// System.out.println(cellValue);
						// System.out.println(cell.getRowIndex());
						// cellMap.put(cell.getRowIndex(), cellValue);
						// }
					}

				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fileIn.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public void writeExcelTestResult(String TestCase, String Result) {
		try {
			// FileInputStream file = new FileInputStream(new File(
			// "D:/Adda52-Automation/Adda52/My.xls"));

			FileInputStream file = new FileInputStream(new File("My.xls"));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(GlobalSheetIndex);
			Cell cell = null;
			int rowIndex = 1;
			Iterator<Entry<Integer, String>> itr = cellMap.entrySet()
					.iterator();

			while (itr.hasNext()) {
				Entry<Integer, String> cellEntry = itr.next();
				String value = cellEntry.getValue();
				if (TestCase.equals(value)) {
					rowIndex = cellEntry.getKey();
					break;
				}
			}
			// Update the value of cell and put the result at 6 index
			cell = sheet.getRow(rowIndex).getCell(6);
			cell.setCellValue(Result);

			file.close();

			// FileOutputStream outFile = new FileOutputStream(new File(
			// "D:/Adda52-Automation/Adda52/My.xls"));

			FileOutputStream outFile = new FileOutputStream(new File("My.xls"));
			workbook.write(outFile);
			outFile.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeExcelTestResult(HashMap<String, String> TestResultMap) {
		try {
			// FileInputStream file = new FileInputStream(new File(
			// "D:/Adda52-Automation/Adda52/My.xls"));

			FileInputStream file = new FileInputStream(new File("My.xls"));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(GlobalSheetIndex);
			System.out.println("GLOBAL INDEX::" + GlobalSheetIndex);
			Cell cell = null;
			int rowIndex = 1;
			Iterator<Entry<Integer, String>> itr = null;

			if (TestResultMap != null && !TestResultMap.isEmpty()) {

				Iterator<Entry<String, String>> resultMapItr = TestResultMap
						.entrySet().iterator();

				while (resultMapItr.hasNext()) {
					itr = cellMap.entrySet().iterator();
					Entry<String, String> TestCaseEntry = resultMapItr.next();
					String TestCase = TestCaseEntry.getKey();
					String TestResult = TestCaseEntry.getValue();
					// System.out.println("TestCase::" + TestCase);
					while (itr.hasNext()) {
						Entry<Integer, String> cellEntry = itr.next();
						String value = cellEntry.getValue();
						// System.out.println("Excel TestCase::" + value);

						if (TestCase.equals(value)) {
							// System.out.println("TestCase::" + TestCase);
							rowIndex = cellEntry.getKey();
							break;
						}
					}
					// Update the value of cell and put the result at 6 index
					cell = sheet.getRow(rowIndex).getCell(6);
					if (cell == null) {
						cell = sheet.getRow(rowIndex).createCell(6);
					}
					cell.setCellValue(TestResult);

				}

				file.close();

				// FileOutputStream outFile = new FileOutputStream(new File(
				// "D:/Adda52-Automation/Adda52/My.xls"));
				//
				FileOutputStream outFile = new FileOutputStream(new File(
						"My.xls"));
				workbook.write(outFile);
				outFile.close();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeExcelTestResult(HashMap<String, String> TestResultMap,
			String fileName, int resultCell) {
		try {
			// FileInputStream file = new FileInputStream(new File(
			// "D:/Adda52-Automation/Adda52/" + fileName));

			FileInputStream file = new FileInputStream(new File(fileName));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(GlobalSheetIndex);
			Cell cell = null;
			int rowIndex = 1;
			Iterator<Entry<Integer, String>> itr = null;

			if (TestResultMap != null && !TestResultMap.isEmpty()) {

				Iterator<Entry<String, String>> resultMapItr = TestResultMap
						.entrySet().iterator();

				while (resultMapItr.hasNext()) {
					itr = cellMap.entrySet().iterator();
					Entry<String, String> TestCaseEntry = resultMapItr.next();
					String TestCase = TestCaseEntry.getKey();
					String TestResult = TestCaseEntry.getValue();
					while (itr.hasNext()) {
						Entry<Integer, String> cellEntry = itr.next();
						String value = cellEntry.getValue();
						if (TestCase.equals(value)) {
							rowIndex = cellEntry.getKey();
							break;
						}
					}
					// Update the value of cell and put the result at 6 index
					cell = sheet.getRow(rowIndex).getCell(resultCell);
					if (cell == null) {
						cell = sheet.getRow(rowIndex).createCell(resultCell);
					}
					cell.setCellValue(TestResult);

				}

				file.close();

				// FileOutputStream outFile = new FileOutputStream(new File(
				// "D:/Adda52-Automation/Adda52/" + fileName));

				FileOutputStream outFile = new FileOutputStream(new File(
						fileName));
				workbook.write(outFile);
				outFile.close();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<HashMap<String, Object>> readUserData() {
		List<HashMap<String, Object>> userMapList = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> userMap = new HashMap<String, Object>();
		FileInputStream fileIn = null;
		HSSFWorkbook wb = null;
		try {
			fileIn = new FileInputStream("User.xls");
			wb = new HSSFWorkbook(fileIn);
			for (int i = 0; i < wb.getNumberOfSheets(); i++) {

				HSSFSheet sheet = wb.getSheetAt(i);
				HSSFRow row = null;
				Cell cell;
				for (int j = 1; j < sheet.getLastRowNum() + 1; j++) {
					userMap = new HashMap<String, Object>();
					row = sheet.getRow(j);
					for (int k = 0; k < 5 + 1; k++) {
						boolean boolString = true;
						cell = row.getCell(k, Row.CREATE_NULL_AS_BLANK);
						if (cell != null) {
							int type = cell.getCellType();
							if (type == HSSFCell.CELL_TYPE_STRING) {
								// String cellValue = cell
								// .getRichStringCellValue().toString();
								boolString = true;
							} else if (type == HSSFCell.CELL_TYPE_NUMERIC) {
								// double cellValue =
								// cell.getNumericCellValue();
								boolString = false;
							}
							if (k == 0) {
								// System.out.println("userName:::"
								// + cell.getStringCellValue());
								userMap.put(
										"userName",
										boolString == true ? cell
												.getStringCellValue() : String
												.valueOf(cell
														.getNumericCellValue()));
							}
							if (k == 1) {
								// System.out.println("pass:::"
								// + cell.getStringCellValue());
								userMap.put(
										"password",
										boolString == true ? cell
												.getStringCellValue() : String
												.valueOf(cell
														.getNumericCellValue()));
							}
							if (k == 2) {
								// System.out.println("email:::"
								// + cell.getStringCellValue());
								userMap.put(
										"email",
										boolString == true ? cell
												.getStringCellValue() : String
												.valueOf(cell
														.getNumericCellValue()));
							}
							if (k == 3) {
								// System.out.println("birth:::"
								// + cell.getNumericCellValue());
								userMap.put(
										"birthYear",
										boolString == true ? cell
												.getStringCellValue() : String
												.valueOf(cell
														.getNumericCellValue()));
							}
							if (k == 4) {
								// System.out.println("gender:::"
								// + cell.getStringCellValue());
								userMap.put(
										"gender",
										boolString == true ? cell
												.getStringCellValue() : String
												.valueOf(cell
														.getNumericCellValue()));
							}
						}
					} // cell loop ends here
					userMapList.add(userMap);

				}// row loop ends here
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fileIn.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return userMapList;
	}

	public List<String> readLinks() {
		List<String> linkList = new ArrayList<String>();
		HashMap<String, Object> userMap = new HashMap<String, Object>();
		FileInputStream fileIn = null;
		HSSFWorkbook wb = null;
		try {
			fileIn = new FileInputStream("Links.xls");
			wb = new HSSFWorkbook(fileIn);
			for (int i = 0; i < wb.getNumberOfSheets(); i++) {

				HSSFSheet sheet = wb.getSheetAt(i);
				HSSFRow row = null;
				Cell cell;
				for (int j = 1; j < sheet.getLastRowNum() + 1; j++) {
					row = sheet.getRow(j);
					cell = row.getCell(0, Row.CREATE_NULL_AS_BLANK);
					if (cell != null) {
						linkList.add(cell.getStringCellValue());
					}
				}// row loop ends here
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				fileIn.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return linkList;
	}

	public void writeExcelSignUpMessage(HashMap<String, String> userResultMap) {
		try {
			System.out.println("Start writing");
			// FileInputStream file = new FileInputStream(new File(
			// "D:/Adda52-Automation/Adda52/User.xls"));

			FileInputStream file = new FileInputStream(new File("User.xls"));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(GlobalSheetIndex);
			Cell cell = null;
			int rowIndex = 1;
			Iterator<Entry<Integer, String>> itr = null;

			if (userResultMap != null && !userResultMap.isEmpty()) {

				Iterator<Entry<String, String>> resultMapItr = userResultMap
						.entrySet().iterator();

				while (resultMapItr.hasNext()) {
					itr = cellMap.entrySet().iterator();
					Entry<String, String> signUpEntry = resultMapItr.next();
					String userName = signUpEntry.getKey();
					String signUpMsg = signUpEntry.getValue();
					System.out.println("userName::" + userName);
					System.out.println("Msg::" + signUpMsg);
					while (itr.hasNext()) {
						Entry<Integer, String> cellEntry = itr.next();
						String value = cellEntry.getValue();
						if (userName.equals(value)) {
							rowIndex = cellEntry.getKey();
							break;
						}
					}
					// Update the value of cell and put the result at 6 index
					cell = sheet.getRow(rowIndex).getCell(5);
					if (cell == null) {
						cell = sheet.getRow(rowIndex).createCell(5);
					}
					cell.setCellValue(signUpMsg);

				}

				file.close();

				// FileOutputStream outFile = new FileOutputStream(new File(
				// "D:/Adda52-Automation/Adda52/User.xls"));

				FileOutputStream outFile = new FileOutputStream(new File(
						"User.xls"));

				workbook.write(outFile);
				outFile.close();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}