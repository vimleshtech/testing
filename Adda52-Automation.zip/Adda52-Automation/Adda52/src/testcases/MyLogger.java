package testcases;

public interface MyLogger {

}
