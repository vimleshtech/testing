package example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBExample {

	public static void main(String[] args) {
		
		
		try
		{			
			Class.forName("com.mysql.jdbc.Driver"); //register the driver 
			Connection con  = DriverManager.getConnection("jdbc:mysql://localhost/selenium", "root", "root");
			
			Statement st = con.createStatement();
			//insert , update, delete data 
			st.executeUpdate("insert into testcase(tid,des) values(1,'login testcase')");
			
			System.out.println("data is saved");
			
			//read 
			ResultSet rs =	st.executeQuery("select * from testcase");
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2));
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		

	}

}
